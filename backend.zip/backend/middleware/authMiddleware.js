import jwt from "jsonwebtoken";
import User from "../models/User.js";

export const protect = async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
    try {
      token = req.headers.authorization.split(" ")[1];

      // verify jwt
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // user find karo
      req.user = await User.findById(decoded.id).select("-password");

      if (!req.user) {
        return res.status(401).json({ message: "User not found" });
      }

      return next(); // yaha pe return karna zaroori hai
    } catch (error) {
      console.error("JWT Error:", error.message);
      return res.status(401).json({ message: "Not authorized, token failed" });
    }
  }

  // agar token hi nahi bheja gaya
  if (!token) {
    return res.status(401).json({ message: "Not authorized, no token" });
  }
};

