import express from 'express';
import cors from 'cors'
import dotenv from 'dotenv'
import connectDB from './config/db.js';
import userRoutes from './routes/userRoutes.js'
import tripRoutes from './routes/tripRoutes.js'
import profileRoutes from './routes/profileRoutes.js'
import expenseRoutes from './routes/expenseRoutes.js'
import destinationRoutes from './routes/destinationRoutes.js'
import authRoutes from './routes/authRoutes.js'

dotenv.config();
connectDB();

const app=express();
app.use(express.json());

app.use(cors({ origin: "http://localhost:5173", credentials: true }));

app.use("/api/users", userRoutes);
app.use('/api/trips', tripRoutes);
app.use("/api/profiles", profileRoutes);
app.use('/api/expenses', expenseRoutes);
app.use('/api/destinations',destinationRoutes)

app.use("/api/users", authRoutes);

const PORT=process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
