// import Profile from "../models/Profile.js";

// export const createProfile = async (req, res) => {
//   try {
//     // check if profile already exists
//     const existingProfile = await Profile.findOne({ user: req.user._id });
//     if (existingProfile) {
//       return res.status(400).json({ success: false, message: "Profile already exists" });
//     }

//     const profile = await Profile.create({
//       ...req.body,
//       user: req.user._id, // logged-in user ka id
//     });

//     res.status(201).json({
//       success: true,
//       message: "Profile created successfully",
//       data: profile
//     });
//   } catch (error) {
//     res.status(400).json({ success: false, message: error.message });
//   }
// };

// export const getProfiles = async (req, res) => {
//   try {
//     const profiles = await Profile.find().populate("user", "name email");
//     res.status(200).json({ success: true, data: profiles });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };

// export const getProfileById = async (req, res) => {
//   try {
//     const profile = await Profile.findById(req.params.id).populate("user", "name email");
//     if (!profile) {
//       return res.status(404).json({ success: false, message: "Profile not found" });
//     }
//     res.status(200).json({ success: true, data: profile });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };

// export const updateProfile = async (req, res) => {
//   try {
//     const profile = await Profile.findOneAndUpdate(
//       { user: req.user._id }, // ensure sirf apna hi profile update kare
//       req.body,
//       { new: true }
//     );

//     if (!profile) {
//       return res.status(404).json({ success: false, message: "Profile not found" });
//     }

//     res.status(200).json({ success: true, message: "Profile updated", data: profile });
//   } catch (error) {
//     res.status(400).json({ success: false, message: error.message });
//   }
// };

// export const deleteProfile = async (req, res) => {
//   try {
//     const profile = await Profile.findOneAndDelete({ user: req.user._id });
//     if (!profile) {
//       return res.status(404).json({ success: false, message: "Profile not found" });
//     }
//     res.status(200).json({ success: true, message: "Profile deleted successfully" });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };


import Expense from "../models/Expense.js";

// Create
export const createExpense = async (req, res) => {
  try {
    const expense = await Expense.create({
      ...req.body,
      user: req.user._id
    });
    res.status(201).json({ success: true, data: expense });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// Get All
export const getExpenses = async (req, res) => {
  try {
    const expenses = await Expense.find({ user: req.user._id });
    res.status(200).json({ success: true, data: expenses });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Get by ID
export const getExpenseById = async (req, res) => {
  try {
    const expense = await Expense.findById(req.params.id);
    if (!expense) {
      return res.status(404).json({ success: false, message: "Expense not found" });
    }
    res.status(200).json({ success: true, data: expense });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Update
export const updateExpense = async (req, res) => {
  try {
    const expense = await Expense.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!expense) {
      return res.status(404).json({ success: false, message: "Expense not found" });
    }
    res.status(200).json({ success: true, data: expense });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

// Delete
export const deleteExpense = async (req, res) => {
  try {
    const expense = await Expense.findByIdAndDelete(req.params.id);
    if (!expense) {
      return res.status(404).json({ success: false, message: "Expense not found" });
    }
    res.status(200).json({ success: true, message: "Expense deleted successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
