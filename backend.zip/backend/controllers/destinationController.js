import Destination from "../models/Destination.js";

export const createDestination = async (req, res) => {
  try {
    const { name, description, location } = req.body;

    const destination = await Destination.create({
      name,
      description,
      location,
      createdBy: req.user._id,  // ✅ link with logged-in user
    });

    res.status(201).json({
      success: true,
      message: "Destination created successfully",
      data: destination,
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const getDestinations = async (req, res) => {
  try {
    const destinations = await Destination.find({ createdBy: req.user._id });
    res.json({ success: true, data: destinations });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const getDestinationById = async (req, res) => {
  try {
    const destination = await Destination.findById(req.params.id);
    if (!destination) return res.status(404).json({ success: false, message: "Destination not found" });

    if (destination.createdBy.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: "Not authorized to view this destination" });
    }

    res.json({ success: true, data: destination });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const updateDestination = async (req, res) => {
  try {
    let destination = await Destination.findById(req.params.id);
    if (!destination) return res.status(404).json({ success: false, message: "Destination not found" });

    if (destination.createdBy.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: "Not authorized to update this destination" });
    }

    destination = await Destination.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, message: "Destination updated", data: destination });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const deleteDestination = async (req, res) => {
  try {
    const destination = await Destination.findById(req.params.id);
    if (!destination) return res.status(404).json({ success: false, message: "Destination not found" });

    if (destination.createdBy.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: "Not authorized to delete this destination" });
    }

    await Destination.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: "Destination deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
