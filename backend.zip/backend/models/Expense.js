import mongoose from 'mongoose';

const expenseSchema = new mongoose.Schema({
  trip: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Trip',
    required: [true, "Trip reference is required"]
  },
  amount: {
    type: Number,
    required: [true, "Amount is required"],
    min: [1, "Amount must be at least 1"] 
  },
  category: {
    type: String,
    enum: ['Travel', 'Food', 'Accommodation', 'Misc'],
    default: 'Misc'
  },
  description: {
    type: String,
    trim: true,
    maxlength: [200, "Description cannot exceed 200 characters"]
  },
  date: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

const Expense = mongoose.model("Expense", expenseSchema);

export default Expense;
