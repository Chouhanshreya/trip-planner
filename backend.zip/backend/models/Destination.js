import mongoose from 'mongoose';

const destinationSchema = new mongoose.Schema({
  name: { 
    type: String, 
    required: [true, "Destination name is required"],
    trim: true,
    minlength: [2, "Destination name must have at least 2 characters"],
    maxlength: [100, "Destination name cannot exceed 100 characters"]
  },
  country: { 
    type: String, 
    required: [true, "Country is required"],
    trim: true
  },
  description: { 
    type: String,
    maxlength: [500, "Description cannot exceed 500 characters"],
    trim: true
  },
  createdBy: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  }
}, {
  timestamps: true  
});

const Destination = mongoose.model("Destination", destinationSchema);

export default Destination;
