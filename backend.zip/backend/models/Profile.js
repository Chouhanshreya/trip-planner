import mongoose from 'mongoose';

const profileSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true 
  },
  fullName: {
    type: String,
    trim: true,
    minlength: [3, "Full name must be at least 3 characters"],
    maxlength: [100, "Full name cannot be more than 100 characters"]
  },
  phone: {
    type: String,
    trim: true,
    match: [/^\d{10}$/, "Phone number must be 10 digits"] 
  },
  address: {
    type: String,
    trim: true,
    maxlength: [200, "Address cannot exceed 200 characters"]
  },
  bio: {
    type: String,
    trim: true,
    maxlength: [500, "Bio cannot exceed 500 characters"]
  }
}, {
  timestamps: true 
});

const Profile = mongoose.model("Profile", profileSchema);

export default Profile;
