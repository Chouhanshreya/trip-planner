import mongoose from 'mongoose';

const chatSchema = new mongoose.Schema({
  profile: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Profile', 
    required: true
  },
  message: {
    type: String,
    required: [true, "Message is required"],
    trim: true,
    maxlength: [1000, "Message cannot exceed 1000 characters"]
  },
  sender: {
    type: String,
    enum: ['user', 'bot'],
    required: true
  },
  relatedTrip: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Trip'
  }
}, {
  timestamps: true  
});

const Chat = mongoose.model("Chat", chatSchema);

export default Chat;
