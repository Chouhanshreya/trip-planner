import mongoose from "mongoose";

const tripSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "Trip title is required"],
    trim: true,
    minlength: [3, "Title must be at least 3 characters"],
    maxlength: [100, "Title cannot be more than 100 characters"]
  },
  destination: {
    type: String,
    required: [true, "Destination is required"],
    trim: true,
    minlength: [2, "Destination must be at least 2 characters"],
    maxlength: [100, "Destination cannot be more than 100 characters"]
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  }
}, {
  timestamps: true
});


const Trip = mongoose.model("Trip", tripSchema);

export default Trip;
