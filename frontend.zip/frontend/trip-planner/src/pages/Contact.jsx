export default function Contact() {
  return (
    <div className="flex flex-col items-center justify-center text-center px-6 mt-24">
      <h2 className="text-4xl font-bold text-gray-800 mb-4">Contact Us</h2>
      <p className="text-gray-600 max-w-xl mb-6">
        Have questions or feedback? We'd love to hear from you. Reach out to us anytime!
      </p>
      <form className="w-full max-w-md space-y-4">
        <input 
          type="text" 
          placeholder="Your Name" 
          className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <input 
          type="email" 
          placeholder="Your Email" 
          className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <textarea 
          placeholder="Your Message" 
          className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 h-28"
        ></textarea>
        <button 
          type="submit" 
          className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition"
        >
          Send Message
        </button>
      </form>
    </div>
  );
}
