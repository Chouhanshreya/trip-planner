// import logo from "../assets/logo/1.jpeg";   // ✅ sahi path daala

// export default function Home() {
//   const Navbar = () => (
//     <header className="fixed top-0 left-0 w-full bg-white shadow-md px-6 py-4 flex items-center justify-between z-50">
//       {/* Left - Logo + Name */}
//       <div className="flex items-center space-x-2">
//         <img
//           src={logo}
//           alt="TripPlanner Logo"
//           className="h-8 w-8 object-cover rounded-full"
//         />
//         <h1 className="text-xl font-bold text-blue-600">TripPlanner</h1>
//       </div>

//       {/* Middle - Navigation Links */}
//       <nav className="hidden md:flex space-x-6">
//         <a href="/home" className="text-gray-700 hover:text-blue-600">Home</a>
//         <a href="/trips" className="text-gray-700 hover:text-blue-600">My Trips</a>
//         <a href="/about" className="text-gray-700 hover:text-blue-600">About</a>
//         <a href="/contact" className="text-gray-700 hover:text-blue-600">Contact</a>
//       </nav>
// <button className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg shadow-md">
//   Logout
// </button>
//     </header>
//   );

//   return (
//     <div className="flex flex-col min-h-screen bg-gray-50">
//       {/* ✅ Navbar call yahan ho rahi hai */}
//       <Navbar />

//       {/* Hero Section */}
//       <main className="flex flex-col flex-grow items-center justify-center text-center px-4 mt-24">
//         <h2 className="text-4xl md:text-5xl font-extrabold text-gray-800 mb-4">
//           An easier trip, every time ✈️
//         </h2>
//         <p className="text-lg md:text-xl text-gray-600 max-w-2xl mb-6">
//           All your travel plans in one app — smart, simple, and stress-free.
//         </p>
//         <button className="bg-blue-600 hover:bg-blue-700 text-white text-lg px-6 py-3 rounded-xl shadow-lg">
//           Get Started
//         </button>
//       </main>

//       {/* Footer */}
//       <footer className="bg-white border-t text-center py-4 text-gray-500 text-sm">
//         © {new Date().getFullYear()} TripPlanner. All Rights Reserved.
//       </footer>
//     </div>
//   );
// }
export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center text-center min-h-screen w-full bg-gradient-to-r from-blue-50 to-blue-100 px-6">
      

      <h2 className="text-4xl md:text-5xl font-extrabold text-gray-800 mb-4">
        An easier trip, every time ✈️
      </h2>
 
      <p className="text-lg md:text-xl text-gray-600 max-w-3xl mb-6">
        All your travel plans in one app — smart, simple, and stress-free. 
        Plan with ease, travel with confidence.
      </p>

      <button className="bg-blue-600 hover:bg-blue-700 text-white text-lg px-6 py-3 rounded-xl shadow-lg">
        Get Started
      </button>
    </div>
  );
}
