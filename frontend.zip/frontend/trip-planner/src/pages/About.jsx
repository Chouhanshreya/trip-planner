export default function About() {
  return (
    <div className="flex flex-col items-center justify-center text-center px-6 mt-24">
      <h2 className="text-4xl font-bold text-gray-800 mb-4">About TripPlanner</h2>
      <p className="text-gray-600 max-w-xl">
        TripPlanner is your personal travel assistant. Our goal is to make planning trips easier, smarter, and stress-free — so you can focus on enjoying the journey.
      </p>
    </div>
  );
}
