export default function Trips() {
  return (
    <div className="flex flex-col items-center justify-center text-center px-6 mt-24">
      <h2 className="text-4xl font-bold text-gray-800 mb-4">My Trips</h2>
      <p className="text-gray-600 max-w-xl">
        Track and manage all your travel plans here. Add new trips, view itineraries, and keep everything organized in one place.
      </p>
    </div>
  );
}
