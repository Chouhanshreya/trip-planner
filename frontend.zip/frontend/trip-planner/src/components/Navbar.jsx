// import React, { useState } from "react";
// import logo from "../assets/logo/1.jpeg"; // apna logo path check karna

// const Navbar = () => {
//   const [isOpen, setIsOpen] = useState(false);

//   return (
//     <nav className="fixed top-0 left-0 w-full bg-white shadow-md z-50">
//       <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
        
//         {/* Left: Logo + Name */}
//         <div className="flex items-center space-x-2 cursor-pointer">
//           <img
//             src={logo}
//             alt="TripPlanner Logo"
//             className="h-8 w-8 rounded-full object-cover"
//             style={{ maxWidth: "100px", maxHeight: "100px" , padding:"0px"}}
//           />
//           <h1 className="text-lg font-semibold text-blue-600">TripPlanner</h1>
//         </div>

//         {/* Center: Navigation Links */}
//         <div className="hidden md:flex items-center space-x-6">
//           <a href="/home" className="text-gray-700 hover:text-blue-600">Home</a>
//           <a href="/trips" className="text-gray-700 hover:text-blue-600">My Trips</a>
//           <a href="/about" className="text-gray-700 hover:text-blue-600">About</a>
//           <a href="/contact" className="text-gray-700 hover:text-blue-600">Contact</a>
//         </div>

//         {/* Right: Logout Button */}
//         <div className="hidden md:flex">
//           <button className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg shadow-md">
//            Logout
//         </button>
//         </div>

//         {/* Mobile Menu Button */}
//         <div className="md:hidden">
//           <button
//             onClick={() => setIsOpen(!isOpen)}
//             className="text-gray-700 focus:outline-none text-2xl"
//           >
//             ☰
//           </button>
//         </div>
//       </div>

//       {/* Mobile Dropdown */}
//       {isOpen && (
//         <div className="md:hidden bg-white shadow-md">
//           <a href="/home" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">Home</a>
//           <a href="/trips" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">My Trips</a>
//           <a href="/about" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">About</a>
//           <a href="/contact" className="block px-4 py-2 text-gray-700 hover:bg-gray-100">Contact</a>
//           <button className="w-full text-left px-4 py-2 bg-blue-600 text-white hover:bg-blue-700 transition">
//             Logout
//           </button>
//         </div>
//       )}
//     </nav>
//   );
// };

// export default Navbar;


import { Link, useNavigate } from "react-router-dom";
import logo from "../assets/logo/1.jpeg";

const Navbar = () => {
  const navigate = useNavigate();

  return (
    <nav className="fixed top-0 left-0 w-full bg-white shadow-md z-50">
      <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
        
        {/* Logo + Name */}
        <div className="flex items-center space-x-2 cursor-pointer">
          <img src={logo} alt="TripPlanner Logo" className="h-10 w-10 rounded-full" />
          <h1 className="text-xl font-bold text-blue-600">TripPlanner</h1>
        </div>

        {/* Links */}
        <div className="hidden md:flex space-x-6">
          <Link to="/" className="hover:text-blue-600">Home</Link>
          <Link to="/trips" className="hover:text-blue-600">My Trips</Link>
          <Link to="/about" className="hover:text-blue-600">About</Link>
          <Link to="/contact" className="hover:text-blue-600">Contact</Link>
        </div>

        {/* Sign In Button */}
        <div>
          <button 
            onClick={() => navigate("/login")}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow-md"
          >
            Sign In
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
